from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from testapp.forms import Userform
from django.http import HttpResponseRedirect
# Create your views here.
def base(request):
	return render(request,"testapp/base.html")

def home(request):
	return render(request,"testapp/home.html")

def profile(request):
	# return redirect('/')
	return render(request,"testapp/profile.html")

def java(request):
	return render(request,"testapp/java.html")

@login_required
def about(request):
	return render(request,"testapp/about.html")

def logout(request):
	return render(request,"testapp/logout.html")

def signup(request):
	form=Userform()
	if request.method=="POST":
		form=Userform(request.POST)
		if form.is_valid():
			user=form.save()
			user.set_password(user.password)
			user.save()
		return HttpResponseRedirect('/accounts/login')
	return render(request,"testapp/signup.html",{'form':form})
